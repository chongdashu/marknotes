# MarkNotes

A simple online note taking system that accomplishes two goals:

1. Allows note taking within the browser using markdown notiation.
2. Renders the markdown within the browser upon saving.

## Status

This project is in-development, though it works.A

## Preview
A working preview of this is available over [here](http://people.csail.mit.edu/marknotes/).

## How to use
Just launch `index.html` in your browser, and begin typing in the text field. The markdown will automatically be previewed on the right hand side.


